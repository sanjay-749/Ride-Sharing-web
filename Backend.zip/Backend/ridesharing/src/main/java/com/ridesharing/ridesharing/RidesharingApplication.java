package com.ridesharing.ridesharing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RidesharingApplication {

	public static void main(String[] args) {
		SpringApplication.run(RidesharingApplication.class, args);
	}

}
